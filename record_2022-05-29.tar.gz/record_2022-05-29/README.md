I have trimmed away some `Received` headers from the receiving mail system, and from my local mail system.  The emails are otherwise unmodified.

For ease of reading with almost any mail client, I have presented this in maildir format, and also given each email a `.eml` extension.

Hyperion
